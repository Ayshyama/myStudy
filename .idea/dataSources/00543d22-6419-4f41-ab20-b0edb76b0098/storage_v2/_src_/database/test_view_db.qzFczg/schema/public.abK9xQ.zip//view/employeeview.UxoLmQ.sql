CREATE VIEW employeeview(firstname, lastname, salary) AS
SELECT employees.firstname,
       employees.lastname,
       employees.salary
FROM employees
WITH CASCADED CHECK OPTION;

ALTER TABLE employeeview
    OWNER TO postgres;

